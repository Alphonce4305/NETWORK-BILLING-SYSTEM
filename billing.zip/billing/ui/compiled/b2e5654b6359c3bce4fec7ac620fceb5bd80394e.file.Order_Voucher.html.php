<?php /* Smarty version Smarty-3.1.13, created on 2021-04-10 13:14:19
         compiled from "C:\xampp\htdocs\billing\pages\Order_Voucher.html" */ ?>
<?php /*%%SmartyHeaderCode:41358624760717a7b4369f3-82573930%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2e5654b6359c3bce4fec7ac620fceb5bd80394e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\billing\\pages\\Order_Voucher.html',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '41358624760717a7b4369f3-82573930',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60717a7b438ca3_98611931',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60717a7b438ca3_98611931')) {function content_60717a7b438ca3_98611931($_smarty_tpl) {?>You can buy a voucher in my home<br><br><br>Dapatkan Voucher Internet di Warung terdekat<?php }} ?>