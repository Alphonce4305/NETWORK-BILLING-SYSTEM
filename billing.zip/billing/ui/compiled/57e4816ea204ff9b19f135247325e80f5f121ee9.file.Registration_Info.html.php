<?php /* Smarty version Smarty-3.1.13, created on 2021-04-16 17:24:20
         compiled from "C:\xampp\htdocs\billing\pages\Registration_Info.html" */ ?>
<?php /*%%SmartyHeaderCode:206299961060799e1470a596-48362913%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '57e4816ea204ff9b19f135247325e80f5f121ee9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\billing\\pages\\Registration_Info.html',
      1 => 1618059215,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '206299961060799e1470a596-48362913',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60799e14762319_74915284',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60799e14762319_74915284')) {function content_60799e14762319_74915284($_smarty_tpl) {?> style="text-align: center;"><b>PLEASE PURCHASE VOUCHER TO REGISTER.</b>><font face="comic sans ms">For more inquiries,</font>><font face="comic sans ms">Call: 0740 216 370</font>><font face="comic sans ms">Email: info@diamondhub.co.ke</font>><font face="comic sans ms">Website : www.diamondhub.co.ke</font><?php }} ?>