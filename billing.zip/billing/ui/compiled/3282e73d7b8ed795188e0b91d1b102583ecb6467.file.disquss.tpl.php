<?php /* Smarty version Smarty-3.1.13, created on 2021-04-10 12:28:12
         compiled from "ui\theme\default\disquss.tpl" */ ?>
<?php /*%%SmartyHeaderCode:204149616560716facb3a196-53021498%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3282e73d7b8ed795188e0b91d1b102583ecb6467' => 
    array (
      0 => 'ui\\theme\\default\\disquss.tpl',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '204149616560716facb3a196-53021498',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60716facdf3496_15624641',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60716facdf3496_15624641')) {function content_60716facdf3496_15624641($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


					<div class="row">
						<div class="col-sm-12">
							<div class="panel panel-hovered mb20 panel-default">
								<div class="panel-heading">Public Disquss</div>
								<div class="panel-body">
									<div id="disqus_thread"></div>
										<script>
											var disqus_config = function () {
											this.page.url = "https://ibnux.github.io/phpmixbill/diskusi.html";  // Replace PAGE_URL with your page's canonical URL variable
											this.page.identifier = "phpmixbill"; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
											};
											(function() { // DON'T EDIT BELOW THIS LINE
											var d = document, s = d.createElement('script');
											s.src = 'https://phpmixbill.disqus.com/embed.js';
											s.setAttribute('data-timestamp', +new Date());
											(d.head || d.body).appendChild(s);
											})();
										</script>
										<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>								
								</div>
							</div>
						</div>
					</div>

<?php echo $_smarty_tpl->getSubTemplate ("sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>