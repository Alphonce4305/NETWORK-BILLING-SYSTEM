<?php /* Smarty version Smarty-3.1.13, created on 2021-04-16 17:21:48
         compiled from "ui\theme\default\print-voucher.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31746948960799d7c0ecb38-38269714%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd2e3abff7d08228215d1a215a7e39365a7c51bd8' => 
    array (
      0 => 'ui\\theme\\default\\print-voucher.tpl',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31746948960799d7c0ecb38-38269714',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_title' => 0,
    '_theme' => 0,
    '_url' => 0,
    'from_id' => 0,
    'limit' => 0,
    'pagebreak' => 0,
    'plans' => 0,
    'plan' => 0,
    'planid' => 0,
    '_L' => 0,
    'v' => 0,
    'vc' => 0,
    'jml' => 0,
    'vs' => 0,
    '_c' => 0,
    'xfooter' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60799d7d1e6e84_45386902',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60799d7d1e6e84_45386902')) {function content_60799d7d1e6e84_45386902($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <title><?php echo $_smarty_tpl->tpl_vars['_title']->value;?>
</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/images/favicon.ico">
    <style>
	.ukuran {
		size:A4;
	}
	
	body,td,th {
		font-size: 12px;
		font-family: Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	}
	page[size="A4"] {
	  background: white;
	  width: 21cm;
	  height: 29.7cm;
	  display: block;
	  margin: 0 auto;
	  margin-bottom: 0.5cm;
	  html, body {
		width: 210mm;
		height: 297mm;
	  }
	}
	@media print {
        body {
            size: auto;
            margin: 0;
            box-shadow: 0;
        }
        page[size="A4"] {
            margin: 0;
            size: auto;
            box-shadow: 0;
        }
        .page-break	{ display: block; page-break-before: always; }
        .no-print, .no-print *
        {
            display: none !important;
        }
    }
    </style>
</head>

<body>
<page size="A4">
        <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
prepaid/print-voucher/" class="no-print">
        <table width="100%" border="0" cellspacing="0" cellpadding="1" class="btn btn-default btn-sm">
            <tr>
                <td>ID &gt; <input type="text" name="from_id" style="width:40px" value="<?php echo $_smarty_tpl->tpl_vars['from_id']->value;?>
"> limit <input type="text" name="limit" style="width:40px" value="<?php echo $_smarty_tpl->tpl_vars['limit']->value;?>
"></td>
                <td>PageBreak after  <input type="text" style="width:40px" name="pagebreak" value="<?php echo $_smarty_tpl->tpl_vars['pagebreak']->value;?>
"> vouchers</td>
                <td>Plans <select id="plan_id" name="planid" style="width:150px">
                <option value="0">--all--</option>
                <?php  $_smarty_tpl->tpl_vars['plan'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['plan']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['plans']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['plan']->key => $_smarty_tpl->tpl_vars['plan']->value){
$_smarty_tpl->tpl_vars['plan']->_loop = true;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['plan']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['plan']->value['id']==$_smarty_tpl->tpl_vars['planid']->value){?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['plan']->value['name_plan'];?>
</option>
                <?php } ?>
                </select></td>
                <td><button type="submit">submit</button></td>
            </tr>
        </table><hr>
        <center><button type="button" id="actprint" class="btn btn-default btn-sm no-print"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Click_Here_to_Print'];?>
</button><br>
        <?php echo $_smarty_tpl->tpl_vars['_L']->value['Print_Info'];?>
<br>
        show <?php echo count($_smarty_tpl->tpl_vars['v']->value);?>
 vouchers from <?php echo $_smarty_tpl->tpl_vars['vc']->value;?>
 vouchers<br>
        from ID <?php echo $_smarty_tpl->tpl_vars['v']->value[0]['id'];?>
 limit <?php echo $_smarty_tpl->tpl_vars['limit']->value;?>
 vouchers
        </center>
        </form>
        <div id="printable">
            <hr>
            <?php  $_smarty_tpl->tpl_vars['vs'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vs']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['v']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vs']->key => $_smarty_tpl->tpl_vars['vs']->value){
$_smarty_tpl->tpl_vars['vs']->_loop = true;
?>
            <?php $_smarty_tpl->tpl_vars['jml'] = new Smarty_variable($_smarty_tpl->tpl_vars['jml']->value+1, null, 0);?>
            <table width="100%" height="200" border="0" cellspacing="0" cellpadding="1" style="margin-bottom:5px">
                <tbody>
                    <tr><td align="center" valign="middle"></td></tr>
                    <tr>
                    <td align="center" valign="top">
                        <table width="100%" border="0" cellspacing="0" cellpadding="2">
                        <tr>
                            <td width="50%" valign="middle" style="padding-right:10px">
                            <center><strong style="font-size:38px"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Voucher_Hotspot'];?>
</strong><span class="no-print">  ID <?php echo $_smarty_tpl->tpl_vars['vs']->value['id'];?>
</span></center>
                            <table width="100%" border="1" cellspacing="0" cellpadding="4" bordercolor="#757575">
                                <tbody>
                                <tr>
                                    <td valign="middle" align="center" style="font-size:25px"><?php echo $_smarty_tpl->tpl_vars['_c']->value['currency_code'];?>
 <?php echo number_format($_smarty_tpl->tpl_vars['vs']->value['price'],2,$_smarty_tpl->tpl_vars['_c']->value['dec_point'],$_smarty_tpl->tpl_vars['_c']->value['thousands_sep']);?>
</td>
                                </tr>
                                <tr>
                                    <td valign="middle" align="center" style="font-size:20px"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Code_Voucher'];?>
</td>
                                </tr>
                                <tr>
                                    <td valign="middle" align="center" style="font-size:25px"><?php echo $_smarty_tpl->tpl_vars['vs']->value['code'];?>
</td>
                                </tr>
                                <tr>
                                    <td valign="middle" align="center" style="font-size:15px"><?php echo $_smarty_tpl->tpl_vars['vs']->value['name_plan'];?>
</td>
                                </tr>
                                </tbody>
                            </table>
                            </td>
                            <td valign="top" style="padding-left:10px">
                                <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['_path']->value)."/../pages/Voucher.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

                            </td>
                        </tr>
                        </table>    
                    </td>
                    </tr>
                </tbody>
                </table>
                <hr>
                <?php if ($_smarty_tpl->tpl_vars['jml']->value==$_smarty_tpl->tpl_vars['pagebreak']->value){?>
                <?php $_smarty_tpl->tpl_vars['jml'] = new Smarty_variable(0, null, 0);?>
                <!-- pageBreak -->
                <div class="page-break"><div class="no-print" style="background-color: #E91E63; color:#FFF;" align="center">-- pageBreak --<hr></div></div>
                <?php }?>
                <?php } ?>
        </div>
</page>
<script src="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/scripts/jquery-1.10.2.js"></script>
<?php if (isset($_smarty_tpl->tpl_vars['xfooter']->value)){?>
    <?php echo $_smarty_tpl->tpl_vars['xfooter']->value;?>

<?php }?>
<script>
    jQuery(document).ready(function() {
        // initiate layout and plugins
        $("#actprint").click(function() {
            window.print();
            return false;
        });
    });
</script>

</body>
</html><?php }} ?>