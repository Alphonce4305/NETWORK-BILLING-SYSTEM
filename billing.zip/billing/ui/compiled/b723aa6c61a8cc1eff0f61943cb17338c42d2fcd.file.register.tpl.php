<?php /* Smarty version Smarty-3.1.13, created on 2021-04-16 17:24:20
         compiled from "ui\theme\default\register.tpl" */ ?>
<?php /*%%SmartyHeaderCode:58554445260799e142b4153-45508242%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b723aa6c61a8cc1eff0f61943cb17338c42d2fcd' => 
    array (
      0 => 'ui\\theme\\default\\register.tpl',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '58554445260799e142b4153-45508242',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    '_title' => 0,
    '_L' => 0,
    '_theme' => 0,
    '_c' => 0,
    'notify' => 0,
    '_url' => 0,
    'username' => 0,
    'fullname' => 0,
    'address' => 0,
    'phonenumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60799e143dfc88_19852534',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60799e143dfc88_19852534')) {function content_60799e143dfc88_19852534($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php echo $_smarty_tpl->tpl_vars['_title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['_L']->value['Register'];?>
</title>
	<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/images/logo.png" type="image/x-icon" />
	
	<!-- Icons -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/fonts/ionicons/css/ionicons.min.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/fonts/font-awesome/css/font-awesome.min.css">

	<!-- Plugins -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/plugins/waves.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/plugins/perfect-scrollbar.css">
	
	<!-- Css/Less Stylesheets -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/main.min.css">

 	<!-- <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300' rel='stylesheet' type='text/css'> -->
	<!-- Match Media polyfill for IE9 -->
	<!--[if IE 9]> <script src="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/scripts/ie/matchMedia.js"></script>  <![endif]--> 

</head>
<body id="app" class="app off-canvas body-full">

	<div class="container">
		<div class="hidden-xs" style="height:150px"></div>
		<div class="form-head mb20">
			<h1 class="site-logo h2 mb5 mt5 text-center text-uppercase text-bold" style="text-shadow: 2px 2px 4px #757575;"><?php echo $_smarty_tpl->tpl_vars['_c']->value['CompanyName'];?>
</h1>
			<hr>
		</div>
		<?php if (isset($_smarty_tpl->tpl_vars['notify']->value)){?>
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<?php echo $_smarty_tpl->tpl_vars['notify']->value;?>

				</div>
			</div>
		<?php }?>
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-default">
				<div class="panel-heading"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Registration_Info'];?>
</div>
				<div class="panel-body" style="height:375px;max-height:375px;overflow:scroll;">
					<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['_path']->value)."/../pages/Registration_Info.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

				</div>
				</div>
			</div>
			<form class="form-horizontal" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
register/post" method="post">
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading">1. <?php echo $_smarty_tpl->tpl_vars['_L']->value['Register_Member'];?>
</div>
					<div class="panel-body">
						<div class="form-container">
							<div class="md-input-container md-float-label">
								<input type="text" required class="md-input" id="username" value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['_L']->value['Phone_Number'];?>
" name="username">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Username'];?>
</label>
							</div>
							<div class="md-input-container md-float-label">
								<input type="text" required class="md-input" id="fullname" value="<?php echo $_smarty_tpl->tpl_vars['fullname']->value;?>
" name="fullname">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Full_Name'];?>
</label>
							</div>
							<div class="md-input-container md-float-label">
								<input type="text" name="address" id="address" value="<?php echo $_smarty_tpl->tpl_vars['address']->value;?>
" class="md-input">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Address'];?>
</label>
							</div>
							<div class="md-input-container md-float-label">
								<input type="text" required class="md-input" value="<?php echo $_smarty_tpl->tpl_vars['phonenumber']->value;?>
" id="phonenumber" name="phonenumber">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Phone_Number'];?>
</label>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading">2. <?php echo $_smarty_tpl->tpl_vars['_L']->value['Register_Member'];?>
</div>
					<div class="panel-body">
						<div class="form-container">
							<div class="md-input-container md-float-label">
								<input type="password" required class="md-input" id="password" name="password">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Password'];?>
</label>
							</div>
							<div class="md-input-container md-float-label">
								<input type="password" required class="md-input" id="cpassword" name="cpassword">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Confirm_Password'];?>
</label>
							</div>
							<hr>
							<div class="md-input-container md-float-label">
								<input type="text" required class="md-input" id="kodevoucher" name="kodevoucher">
								<label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Code_Voucher'];?>
</label>
							</div>
							<div class="btn-group btn-group-justified mb15">
								<div class="btn-group">
									<button class="btn btn-primary waves-effect waves-light" type="submit"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Register'];?>
</button>
								</div>
								<div class="btn-group">
									<a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
login" class="btn btn-success"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Cancel'];?>
</a>
								</div>
							</div> 
						</div>
					</div>
				</div>
			</div>
			</form>
		</div>
	</div>
	<script src="scripts/vendors.js"></script>
</body>
</html><?php }} ?>