<?php /* Smarty version Smarty-3.1.13, created on 2021-05-28 14:22:24
         compiled from "ui\theme\default\login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135668731660717a19561ed9-04779086%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b33358dec39d03ebcaa27d0a249bda154f2b6e2' => 
    array (
      0 => 'ui\\theme\\default\\login.tpl',
      1 => 1622200941,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135668731660717a19561ed9-04779086',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60717a195c1703_30252314',
  'variables' => 
  array (
    '_title' => 0,
    '_L' => 0,
    '_theme' => 0,
    'notify' => 0,
    '_url' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60717a195c1703_30252314')) {function content_60717a195c1703_30252314($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php echo $_smarty_tpl->tpl_vars['_title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['_L']->value['Login'];?>
</title>
	<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/images/logo.png" type="image/x-icon" />
	
	<!-- Css/Less Stylesheets -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/main.min.css">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/styles/custom.min.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
 	<!-- <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300' rel='stylesheet' type='text/css'> -->
	<!-- Match Media polyfill for IE9 -->
	<!--[if IE 9]> <script src="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/scripts/ie/matchMedia.js"></script>  <![endif]--> 

</head>
<body style="background-image: url('<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/images/bg.jpg');background-repeat: no-repeat;background-size: cover;">
	<div class="header">
		<div class="hidden-xs" style="height:150px"></div>
		<div class="form-head" style="text-align: center;">
			<img src="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/images/logo.png" class="logo">
			<h3 class="site-logo text-center text-white">TunapandaNET <br>Community Network</h3>
			</div>
		<?php if (isset($_smarty_tpl->tpl_vars['notify']->value)){?>
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<?php echo $_smarty_tpl->tpl_vars['notify']->value;?>

				</div>
			</div>
		<?php }?>
		<div class="contact">
			<div class="col-md-4 col-md-offset-2">
				<div class="panel panel-default">
				<div class="panel-heading"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Announcement'];?>
</div>
				<div class="panel-body">
					<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['_path']->value)."/../pages/Announcement.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

				</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Sign_In_Member'];?>
</div>
					<div class="panel-body">
						<div class="form-container">
							<form class="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
login/post" method="post">
								<div class="form-row">
									<input type="text" name="username" placeholder="<?php echo $_smarty_tpl->tpl_vars['_L']->value['Phone_Number'];?>
" class="md-input">
									<!-- <label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Username'];?>
</label> -->
								</div>

								<div class="form-row">
									<input type="password" name="password" placeholder="<?php echo $_smarty_tpl->tpl_vars['_L']->value['Password'];?>
" class="md-input">
									<!-- <label><?php echo $_smarty_tpl->tpl_vars['_L']->value['Password'];?>
</label> -->
								</div>

								<div class="clearfix hidden">
									<div class="ui-checkbox ui-checkbox-primary right">
										<label>
											<input type="checkbox"> 
											<span>Remember me</span>
										</label>
									</div>
								</div>
								<div class="btn-group btn-group-justified mb15">
									<div class="btn-group">
										<button type="submit" class="theme-btn"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Login'];?>
</button>
									</div>
									<div class="btn-group">
										<a href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
register" class=" theme-btn btn btn-success"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Register'];?>
</a>
									</div>
								</div> 
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="scripts/vendors.js"></script>

	<style type="text/css">
		.text-white{
			color: #fff;
		}
	</style>
</body>
</html><?php }} ?>