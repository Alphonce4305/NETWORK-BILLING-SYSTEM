<?php /* Smarty version Smarty-3.1.13, created on 2021-04-09 21:17:56
         compiled from "ui\theme\default\page-edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:153107450160709a546f1692-51529207%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '02bedbea07c1329a2e26d02d7fe5b9e14107ff56' => 
    array (
      0 => 'ui\\theme\\default\\page-edit.tpl',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '153107450160709a546f1692-51529207',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'pageHeader' => 0,
    '_L' => 0,
    'htmls' => 0,
    'writeable' => 0,
    '_url' => 0,
    '_theme' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60709a54862031_73636735',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60709a54862031_73636735')) {function content_60709a54862031_73636735($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

					<div class="row">
						<div class="col-sm-12">
							<div class="panel mb20 panel-primary panel-hovered">
								<div class="panel-heading"><?php echo $_smarty_tpl->tpl_vars['_L']->value[$_smarty_tpl->tpl_vars['pageHeader']->value];?>
</div>
								<div id="myNicPanel" style="width: 100%;"></div>
								<div id="panel-edit" class="panel-body"><?php echo $_smarty_tpl->tpl_vars['htmls']->value;?>
</div>
								<?php if ($_smarty_tpl->tpl_vars['writeable']->value){?>
								<div class="panel-footer">
								<a href="javascript:saveIt()" class="btn btn-primary btn-block">SAVE</a>
								<br>
								<p class="help-block"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Info_Page'];?>
</p>
								</div>
								<?php }else{ ?>
								<div class="panel-footer">
									<?php echo $_smarty_tpl->tpl_vars['_L']->value['Failed_Save_Page'];?>

								</div>
								<?php }?>
							</div>
						</div>
					</div>
<form id="formpages" class="hidden" method="post" role="form" action="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
pages/<?php echo $_smarty_tpl->tpl_vars['pageHeader']->value;?>
-post" > 
<textarea name="html" id="html"></textarea>
</form>
<script src="<?php echo $_smarty_tpl->tpl_vars['_theme']->value;?>
/scripts/nicEdit.js"></script>
<script type="text/javascript">
var myNicEditor
bkLib.onDomLoaded(function() {
	myNicEditor = new nicEditor();
	myNicEditor.setPanel('myNicPanel');
	myNicEditor.addInstance('panel-edit');
});
function saveIt(){
	//alert(document.getElementById('panel-edit').innerHTML);
	document.getElementById('html').value = nicEditors.findEditor('panel-edit').getContent()
	document.getElementById('formpages').submit();
}
</script>
						
<?php echo $_smarty_tpl->getSubTemplate ("sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>