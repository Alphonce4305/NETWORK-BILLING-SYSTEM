<?php /* Smarty version Smarty-3.1.13, created on 2021-04-10 13:14:19
         compiled from "ui\theme\default\user-pages.tpl" */ ?>
<?php /*%%SmartyHeaderCode:70657609760717a7b2a3f89-07263711%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '899bff0044ae6f95caf54636c17579620c7b361a' => 
    array (
      0 => 'ui\\theme\\default\\user-pages.tpl',
      1 => 1566515702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '70657609760717a7b2a3f89-07263711',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'pageHeader' => 0,
    '_L' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60717a7b2fcdd4_42848589',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60717a7b2fcdd4_42848589')) {function content_60717a7b2fcdd4_42848589($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("sections/user-header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


					<div class="row">
						<div class="col-sm-12">
							<div class="panel mb20 panel-primary panel-hovered">
								<div class="panel-heading"><?php echo $_smarty_tpl->tpl_vars['_L']->value[$_smarty_tpl->tpl_vars['pageHeader']->value];?>
</div>
								<div class="panel-body">
									<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['_path']->value)."/../pages/".((string)$_smarty_tpl->tpl_vars['PageFile']->value).".html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

								</div>
							</div>
						</div>
					</div>

<?php echo $_smarty_tpl->getSubTemplate ("sections/user-footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>