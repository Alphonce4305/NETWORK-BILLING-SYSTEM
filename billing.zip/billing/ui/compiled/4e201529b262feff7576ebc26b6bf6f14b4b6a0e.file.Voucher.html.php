<?php /* Smarty version Smarty-3.1.13, created on 2021-04-16 17:21:49
         compiled from "C:\xampp\htdocs\billing\pages\Voucher.html" */ ?>
<?php /*%%SmartyHeaderCode:134838442160799d7d74c2a1-89198451%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4e201529b262feff7576ebc26b6bf6f14b4b6a0e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\billing\\pages\\Voucher.html',
      1 => 1618058849,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134838442160799d7d74c2a1-89198451',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60799d7d804977_85384573',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60799d7d804977_85384573')) {function content_60799d7d804977_85384573($_smarty_tpl) {?><center><strong style="font-size:38px">TUNAPANDANET</strong></center>
<table width="100%" border="1" cellspacing="0" cellpadding="4" bordercolor="#757575">
<tbody>
<tr>
    <td valign="top" align="left">Pendaftaran dan Informasi Billing buka <b>billing.ibnux.net</b></td>
</tr>
<tr>
    <td valign="top" align="left">Wireless Hotspot:
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
            <tbody><tr>
                <td>iBNuXnet</td>
                <td>iBNuXnet-P</td>
                <td>iBNuXnet-Q</td>
            </tr>
            <tr>
                <td>CitraGadingBlokP 3/4</td>
                <td>CitraGadingBlokQ 2/3/4/5/6</td>
                <td>iBNuXnet 5Ghz</td>
            </tr>
        </tbody></table>
    </td>
</tr>
<tr>
    <td valign="top" align="left">Voucher yang sudah dibeli tidak dapat dikembalikan</td>
</tr>
<tr>
    <td valign="top" align="center"><b>tnet.hotspot</b></td>
</tr>
</tbody>
</table><?php }} ?>