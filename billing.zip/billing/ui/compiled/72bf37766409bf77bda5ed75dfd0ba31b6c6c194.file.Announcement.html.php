<?php /* Smarty version Smarty-3.1.13, created on 2021-04-10 15:55:35
         compiled from "C:\xampp\htdocs\billing\pages\Announcement.html" */ ?>
<?php /*%%SmartyHeaderCode:27501924660717a19815ce4-80702599%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '72bf37766409bf77bda5ed75dfd0ba31b6c6c194' => 
    array (
      0 => 'C:\\xampp\\htdocs\\billing\\pages\\Announcement.html',
      1 => 1618059040,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27501924660717a19815ce4-80702599',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_60717a1981a898_80620091',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60717a1981a898_80620091')) {function content_60717a1981a898_80620091($_smarty_tpl) {?>Hi Customer,<br>Welcome to TunapandaNET Community Network.<br><b><u>OUR SERVICES</u></b><br><ul><li>Affordable Internet Access</li><li>24Hrs Customer support</li><li>Digital Local Content Creation</li><li>ICT training and Digital Literacy Skills Development</li></ul><?php }} ?>