<?php
	$db_host	    = 'localhost';
	$db_user        = 'root';
	$db_password	= '';
	$db_name	    = 'billing';
	// define('APP_URL', 'http://localhost/billing');
	define('APP_URL', 'http://'.$_SERVER['SERVER_NAME'].'/billing');
	$_app_stage = 'Live';