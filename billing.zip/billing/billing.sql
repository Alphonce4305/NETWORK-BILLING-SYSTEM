-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2021 at 02:29 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appconfig`
--

CREATE TABLE `tbl_appconfig` (
  `id` int(11) NOT NULL,
  `setting` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_appconfig`
--

INSERT INTO `tbl_appconfig` (`id`, `setting`, `value`) VALUES
(1, 'CompanyName', 'TNET NMS'),
(2, 'theme', 'default'),
(3, 'currency_code', 'KES.'),
(4, 'language', 'english'),
(5, 'show-logo', '1'),
(6, 'nstyle', 'blue'),
(7, 'timezone', 'Africa/Nairobi'),
(8, 'dec_point', '.'),
(9, 'thousands_sep', ','),
(10, 'rtl', '0'),
(11, 'address', 'KIBERA-OLYMPIC'),
(12, 'phone', '0740216370'),
(13, 'date_format', 'm/d/Y'),
(14, 'note', 'Thank you...');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bandwidth`
--

CREATE TABLE `tbl_bandwidth` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_bw` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rate_down` int(10) UNSIGNED NOT NULL,
  `rate_down_unit` enum('Kbps','Mbps') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rate_up` int(10) UNSIGNED NOT NULL,
  `rate_up_unit` enum('Kbps','Mbps') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bandwidth`
--

INSERT INTO `tbl_bandwidth` (`id`, `name_bw`, `rate_down`, `rate_down_unit`, `rate_up`, `rate_up_unit`) VALUES
(6, '2mbps', 3, 'Mbps', 2, 'Mbps'),
(7, '5mbps', 6, 'Mbps', 5, 'Mbps'),
(8, '10mbps', 11, 'Mbps', 10, 'Mbps'),
(9, '15mbps', 16, 'Mbps', 10, 'Mbps'),
(10, '20mbps', 21, 'Mbps', 16, 'Mbps'),
(11, '25mbps', 26, 'Mbps', 20, 'Mbps');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customers`
--

CREATE TABLE `tbl_customers` (
  `id` int(10) NOT NULL,
  `username` varchar(45) CHARACTER SET latin1 NOT NULL,
  `password` varchar(45) CHARACTER SET latin1 NOT NULL,
  `fullname` varchar(45) CHARACTER SET latin1 NOT NULL,
  `address` text CHARACTER SET latin1,
  `phonenumber` varchar(20) CHARACTER SET latin1 DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customers`
--

INSERT INTO `tbl_customers` (`id`, `username`, `password`, `fullname`, `address`, `phonenumber`, `created_at`, `last_login`) VALUES
(7, 'admin_user', '123456', 'Alphonce Odhiambo', '52', '+254740216370', '2021-04-17 10:57:39', NULL),
(8, 'Tunapanda', '123456', 'Alphonce Odhiambo', '52', '+254740216370', '2021-04-20 15:49:37', '2021-04-20 18:52:36'),
(9, 'Tnet', '123456', 'Tunapanda NET', 'Tunapanda', '0740216370', '2021-04-28 09:35:59', '2021-05-28 14:59:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `id` int(10) NOT NULL,
  `name` varchar(32) NOT NULL,
  `folder` varchar(32) NOT NULL,
  `author` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`id`, `name`, `folder`, `author`) VALUES
(1, 'Indonesia', 'indonesia', 'Ismail Marzuqi'),
(2, 'English', 'english', 'Ismail Marzuqi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logs`
--

CREATE TABLE `tbl_logs` (
  `id` int(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `userid` int(10) NOT NULL,
  `ip` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_logs`
--

INSERT INTO `tbl_logs` (`id`, `date`, `type`, `description`, `userid`, `ip`) VALUES
(18, '2021-04-17 13:38:51', 'Admin', 'admin Login Successful', 1, '::1'),
(19, '2021-04-20 14:36:01', 'Admin', 'admin Login Successful', 1, '::1'),
(20, '2021-04-20 18:19:56', 'User', 'admin_user Failed Login', 0, '::1'),
(21, '2021-04-20 18:38:26', 'Admin', 'admin Login Successful', 1, '::1'),
(22, '2021-04-20 18:52:36', 'User', 'Tunapanda Login Successful', 8, '192.168.100.254'),
(23, '2021-04-25 11:29:28', 'Admin', 'admin Login Successful', 1, '::1'),
(24, '2021-04-26 11:08:36', 'Admin', 'admin Login Successful', 1, '::1'),
(25, '2021-04-28 10:52:38', 'Admin', 'admin Login Successful', 1, '::1'),
(26, '2021-04-28 12:31:28', 'User', 'Tunapanda Failed Login', 0, '::1'),
(27, '2021-04-28 12:34:39', 'Admin', 'admin Login Successful', 1, '::1'),
(28, '2021-05-03 13:02:27', 'Admin', 'admin Login Successful', 1, '::1'),
(29, '2021-05-04 14:08:27', 'Admin', 'admin Login Successful', 1, '::1'),
(30, '2021-05-05 17:12:24', 'Admin', 'admin Login Successful', 1, '::1'),
(31, '2021-05-12 15:27:04', 'Admin', 'admin Login Successful', 1, '::1'),
(32, '2021-05-20 11:44:17', 'Admin', 'admin Login Successful', 1, '::1'),
(33, '2021-05-28 13:03:45', 'Admin', 'admin Login Successful', 1, '::1'),
(34, '2021-05-28 13:16:43', 'Admin', 'admin Failed Login', 0, '::1'),
(35, '2021-05-28 13:16:55', 'Admin', 'admin Login Successful', 1, '::1'),
(36, '2021-05-28 13:37:37', 'Admin', 'admin Login Successful', 1, '::1'),
(37, '2021-05-28 14:24:21', 'Admin', 'admin Login Successful', 1, '::1'),
(38, '2021-05-28 14:28:49', 'Admin', 'admin Login Successful', 1, '::1'),
(39, '2021-05-28 14:59:58', 'User', 'Tnet Login Successful', 9, '::1'),
(40, '2021-05-28 15:14:01', 'Admin', 'admin Login Successful', 1, '::1'),
(41, '2021-05-28 15:24:01', 'Admin', '[admin]: Settings Saved Successfully', 1, '::1'),
(42, '2021-05-28 15:24:57', 'Admin', '[admin]: Account Created Successfully', 1, '::1'),
(43, '2021-05-28 15:25:40', 'Admin', 'Josephine Login Successful', 3, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `id` int(10) NOT NULL,
  `from_user` varchar(32) CHARACTER SET latin1 NOT NULL,
  `to_user` varchar(32) CHARACTER SET latin1 NOT NULL,
  `title` varchar(60) CHARACTER SET latin1 NOT NULL,
  `message` text CHARACTER SET latin1 NOT NULL,
  `status` enum('0','1') CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_plans`
--

CREATE TABLE `tbl_plans` (
  `id` int(10) NOT NULL,
  `name_plan` varchar(40) CHARACTER SET latin1 NOT NULL,
  `id_bw` int(10) NOT NULL,
  `price` varchar(40) CHARACTER SET latin1 NOT NULL,
  `type` enum('Hotspot','PPPOE') CHARACTER SET latin1 NOT NULL,
  `typebp` enum('Unlimited','Limited') CHARACTER SET latin1 DEFAULT NULL,
  `limit_type` enum('Time_Limit','Data_Limit','Both_Limit') CHARACTER SET latin1 DEFAULT NULL,
  `time_limit` int(10) UNSIGNED DEFAULT NULL,
  `time_unit` enum('Mins','Hrs') CHARACTER SET latin1 DEFAULT NULL,
  `data_limit` int(10) UNSIGNED DEFAULT NULL,
  `data_unit` enum('MB','GB') CHARACTER SET latin1 DEFAULT NULL,
  `validity` int(10) NOT NULL,
  `validity_unit` enum('Days','Months') CHARACTER SET latin1 NOT NULL,
  `shared_users` int(10) DEFAULT NULL,
  `routers` varchar(32) CHARACTER SET latin1 NOT NULL,
  `pool` varchar(40) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_plans`
--

INSERT INTO `tbl_plans` (`id`, `name_plan`, `id_bw`, `price`, `type`, `typebp`, `limit_type`, `time_limit`, `time_unit`, `data_limit`, `data_unit`, `validity`, `validity_unit`, `shared_users`, `routers`, `pool`) VALUES
(9, 'ONHC_STABLE', 10, '20000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', '20mbps_pool'),
(10, 'ONHC-Suite', 11, '25000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', '25mbps_pool'),
(11, 'ONHC-Starter', 9, '15000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', '15mbps_pool'),
(12, 'LINK10', 8, '5000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', 'hotspot_pool'),
(13, 'LINK5', 7, '25000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', '5mbps_pool'),
(14, 'LINK2', 6, '1000', 'PPPOE', NULL, NULL, NULL, NULL, NULL, NULL, 30, 'Days', NULL, 'Router_hAp', '2mbps_pool'),
(15, 'Hotspot1', 11, '100', 'Hotspot', 'Unlimited', 'Time_Limit', 0, 'Hrs', 0, 'MB', 30, 'Days', 1, 'ROUTERBOARD', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pool`
--

CREATE TABLE `tbl_pool` (
  `id` int(10) NOT NULL,
  `pool_name` varchar(40) NOT NULL,
  `range_ip` varchar(40) NOT NULL,
  `routers` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_pool`
--

INSERT INTO `tbl_pool` (`id`, `pool_name`, `range_ip`, `routers`) VALUES
(8, '20mbps_pool', '192.168.20.5-192.168.20.254', 'Router_hAp'),
(9, '25mbps_pool', '192.168.25.5-192.168.25.254', 'Router_hAp'),
(10, '15mbps_pool', '192.168.15.5-192.168.15.254', 'Router_hAp'),
(11, '10mbps_pool', '192.168.10.5-192.168.10.254', 'Router_hAp'),
(12, '5mbps_pool', '192.168.5.5-192.168.5.254', 'Router_hAp'),
(13, '2mbps_pool', '192.168.2.5-192.168.2.254', 'Router_hAp');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_routers`
--

CREATE TABLE `tbl_routers` (
  `id` int(10) NOT NULL,
  `name` varchar(32) CHARACTER SET latin1 NOT NULL,
  `ip_address` varchar(128) CHARACTER SET latin1 NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 NOT NULL,
  `password` varchar(60) CHARACTER SET latin1 NOT NULL,
  `description` varchar(50) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_routers`
--

INSERT INTO `tbl_routers` (`id`, `name`, `ip_address`, `username`, `password`, `description`) VALUES
(6, 'ROUTERBOARD', '10.19.233.222', 'testuser', 'testuser', 'Routes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

CREATE TABLE `tbl_transactions` (
  `id` int(10) NOT NULL,
  `invoice` varchar(25) NOT NULL,
  `username` varchar(32) NOT NULL,
  `plan_name` varchar(40) NOT NULL,
  `price` varchar(40) NOT NULL,
  `recharged_on` date NOT NULL,
  `expiration` date NOT NULL,
  `time` time NOT NULL,
  `method` enum('voucher','admin') NOT NULL,
  `routers` varchar(32) NOT NULL,
  `type` enum('Hotspot','PPPOE') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_transactions`
--

INSERT INTO `tbl_transactions` (`id`, `invoice`, `username`, `plan_name`, `price`, `recharged_on`, `expiration`, `time`, `method`, `routers`, `type`) VALUES
(1, 'INV-63648', 'user1', 'LINK1_PPPoE', '1000', '2021-04-09', '2021-04-10', '21:19:17', 'admin', 'CORE ROUTER', 'PPPOE'),
(2, 'INV-50417', 'TEST_USER1', 'TEST_PPPoE', '1500', '2021-04-09', '2021-04-10', '21:51:19', 'admin', 'Test Router', 'PPPOE'),
(3, 'INV-45401', 'TEST_USER1', 'TEST_HOTSPOT', '100', '2021-04-09', '2021-04-10', '22:00:46', 'admin', 'Test Router', 'Hotspot'),
(4, 'INV-98468', 'TEST_USER1', 'TEST_HOTSPOT', '100', '2021-04-09', '2021-04-10', '22:02:17', 'admin', 'Test Router', 'Hotspot'),
(5, 'INV-60953', 'TEST_USER1', 'TEST_HOTSPOT', '100', '2021-04-10', '2021-04-11', '10:26:55', 'admin', 'Test Router', 'Hotspot'),
(6, 'INV-52416', 'david', 'LINK1', '1000', '2021-04-10', '2021-04-11', '10:41:19', 'admin', 'Test Router', 'PPPOE'),
(7, 'INV-83532', 'david', 'LINK1', '1000', '2021-04-10', '2021-05-10', '10:43:03', 'admin', 'Test Router', 'PPPOE'),
(8, 'INV-12319', 'david', 'LINK1_PPPoE', '1500', '2021-04-10', '2021-05-10', '12:36:03', 'admin', 'Test Router', 'PPPOE'),
(9, 'INV-47239', 'david', 'LINK1_PPPoE', '1500', '2021-04-10', '2021-05-10', '12:53:52', 'admin', 'Test Router', 'PPPOE'),
(10, 'INV-44847', 'pppeo_user', '10mbps_pppeo', '10000', '2021-04-10', '2021-05-10', '14:25:59', 'admin', 'Test Router', 'PPPOE'),
(11, 'INV-44619', 'pppeo_user', '10mbps_pppeo', '10000', '2021-04-10', '2021-05-10', '15:31:40', 'admin', 'Test Router', 'PPPOE'),
(12, 'INV-69623', 'Charles', 'TEST_HOTSPOT', '100', '2021-04-17', '2021-04-18', '11:43:59', 'admin', 'Test Router', 'PPPOE'),
(13, 'INV-31996', 'Charles', '10mbps_pppeo', '10000', '2021-04-17', '2021-05-17', '11:56:18', 'admin', 'Test Router', 'PPPOE'),
(14, 'INV-77062', 'Charles', 'LINK1_PPPoE', '1500', '2021-04-17', '2021-05-17', '12:25:52', 'voucher', 'Test Router', 'PPPOE'),
(15, 'INV-95374', 'admin_user', 'LINK10', '5000', '2021-04-17', '2021-05-17', '13:57:58', 'admin', 'Router_hAp', 'PPPOE'),
(16, 'INV-98477', 'Tnet', 'Hotspot1', '100', '2021-05-28', '2021-06-27', '14:58:32', 'admin', 'ROUTERBOARD', 'Hotspot');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(45) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `fullname` varchar(45) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `password` text CHARACTER SET latin1 NOT NULL,
  `user_type` enum('Admin','Sales') CHARACTER SET latin1 NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET latin1 NOT NULL DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `creationdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `fullname`, `password`, `user_type`, `status`, `last_login`, `creationdate`) VALUES
(1, 'admin', 'Administrator', '$1$W44.ns/.$MUnR0NeBH9xAcXm0Oku2h1', 'Admin', 'Active', '2021-05-28 15:14:01', '2014-06-23 01:43:07'),
(3, 'Josephine', 'Miliza Josephine', '$1$gT8B/CAm$3NGVNo/bl/sgxMzdYY8he0', 'Sales', 'Active', '2021-05-28 15:25:40', '2021-05-28 15:24:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_recharges`
--

CREATE TABLE `tbl_user_recharges` (
  `id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `username` varchar(32) CHARACTER SET latin1 NOT NULL,
  `plan_id` int(10) NOT NULL,
  `namebp` varchar(40) CHARACTER SET latin1 NOT NULL,
  `recharged_on` date NOT NULL,
  `expiration` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(20) CHARACTER SET latin1 NOT NULL,
  `method` enum('voucher','admin') CHARACTER SET latin1 NOT NULL,
  `routers` varchar(32) CHARACTER SET latin1 NOT NULL,
  `type` varchar(15) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_recharges`
--

INSERT INTO `tbl_user_recharges` (`id`, `customer_id`, `username`, `plan_id`, `namebp`, `recharged_on`, `expiration`, `time`, `status`, `method`, `routers`, `type`) VALUES
(7, 7, 'admin_user', 12, 'LINK10', '2021-04-17', '2021-05-17', '13:57:58', 'on', 'admin', 'Router_hAp', 'PPPOE'),
(8, 9, 'Tnet', 15, 'Hotspot1', '2021-05-28', '2021-06-27', '14:58:32', 'on', 'admin', 'ROUTERBOARD', 'Hotspot');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_voucher`
--

CREATE TABLE `tbl_voucher` (
  `id` int(10) NOT NULL,
  `type` enum('Hotspot','PPPOE') CHARACTER SET latin1 NOT NULL,
  `routers` varchar(32) CHARACTER SET latin1 NOT NULL,
  `id_plan` int(10) NOT NULL,
  `code` varchar(55) CHARACTER SET latin1 NOT NULL,
  `user` varchar(45) CHARACTER SET latin1 NOT NULL,
  `status` varchar(25) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_voucher`
--

INSERT INTO `tbl_voucher` (`id`, `type`, `routers`, `id_plan`, `code`, `user`, `status`) VALUES
(1, 'PPPOE', 'Router_hAp', 9, '05CF8DA4BA2E', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_appconfig`
--
ALTER TABLE `tbl_appconfig`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bandwidth`
--
ALTER TABLE `tbl_bandwidth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_plans`
--
ALTER TABLE `tbl_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pool`
--
ALTER TABLE `tbl_pool`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_routers`
--
ALTER TABLE `tbl_routers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_recharges`
--
ALTER TABLE `tbl_user_recharges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_voucher`
--
ALTER TABLE `tbl_voucher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_appconfig`
--
ALTER TABLE `tbl_appconfig`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_bandwidth`
--
ALTER TABLE `tbl_bandwidth`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_customers`
--
ALTER TABLE `tbl_customers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_logs`
--
ALTER TABLE `tbl_logs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_plans`
--
ALTER TABLE `tbl_plans`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_pool`
--
ALTER TABLE `tbl_pool`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_routers`
--
ALTER TABLE `tbl_routers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_user_recharges`
--
ALTER TABLE `tbl_user_recharges`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_voucher`
--
ALTER TABLE `tbl_voucher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
